@echo off
title Space Mirror Lightweighting Agent - FastAPI Server
echo ===============================================================
echo Starting Space Mirror Lightweighting Agent Backend Server...
echo ===============================================================
set PYTHONUTF8=1
"%LOCALAPPDATA%\Programs\Python311\python.exe" -m uvicorn server.main_server:app --host 0.0.0.0 --port 8000 --reload
pause
