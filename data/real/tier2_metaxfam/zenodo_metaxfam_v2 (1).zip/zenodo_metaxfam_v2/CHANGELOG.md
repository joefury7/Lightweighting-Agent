# Changelog

## v2.0.0 — MetaXFam-D (distinct rasterisations)

**Corrects a significant defect in v1. See README.md for the full audit.**

### Fixed
- v1 contained 13,200 cells but only **5,072 distinct geometries (61.6% duplicated)**,
  caused by rasterisation collapse: distinct shape parameters producing identical 48x48
  pixel images. Under a random 75/25 split of v1, **67.7% of test cells had their exact
  geometry in training**, inflating in-distribution scores.
- Generation now rejects a candidate before homogenisation if its exact rasterisation has
  already been accepted (`code/gen_distinct.py`), and reports when a family is EXHAUSTED
  rather than silently emitting copies.

### Added
- `data_benchmark/` MetaXFam-D: 18 families x 172 cells, **3,096 cells, zero duplicates**.
- `data_full_pool/`: all 29 families at full achievable distinct count, 7,190 cells.
- Six re-parameterised families (`*_rich`) that escape exhaustion by gaining shape freedom;
  `circle_iso` preserves the exactly-isotropic circular family (65 distinct, the true
  achievable count at 48x48).
- `audit/` the duplication audit tooling and its results, reproducible on any dataset.

### Changed
- Ten families from v1 fall below the 150-distinct threshold and are excluded from the
  recommended benchmark; they remain in `data_full_pool/`.
- `circle_rich` is elliptical and therefore NOT exactly isotropic, unlike v1's `circle`.

### Not changed
- Solver, material model, density band [0.45, 0.75], and the percolation requirement are
  identical to v1.

### Note on v1
v1 is retained and remains citable; published work refers to it. It is not withdrawn.
Cross-family results on v1 are much less affected than in-distribution results, because
whole families are held out and only 40 duplicate groups span families.
