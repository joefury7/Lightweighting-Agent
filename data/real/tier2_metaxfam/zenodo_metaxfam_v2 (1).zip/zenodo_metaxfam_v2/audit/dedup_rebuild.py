"""
dedup_rebuild.py -- rebuild the evaluation set on DISTINCT geometries and re-measure.

The audit established that MetaXFam22 is 61.6% duplicated at 48x48 (13,200 cells ->
5,072 distinct), that duplication is rasterisation collapse (72.8% -> 92.3% -> 96.7% ->
98.4% as resolution drops 48 -> 24 -> 16 -> 12), and that a random 75/25 split leaks the
exact geometry of 67.7% of test cells into training.

Every number previously computed on the matched subset is therefore suspect, in a specific
direction: in-distribution and random-split scores are inflated by memorisation, while
family-disjoint scores are much less affected (only 40 duplicate groups span families).
So the SPLIT GAP is probably overstated.  This script measures the honest one.

What it does:
 1. Deduplicates each family to distinct geometries.
 2. Reports how many families still have enough distinct cells to be usable, and at what
    per-family cap.  Families with a handful of distinct cells (diag_lattice: 3,
    square: 6, square_lattice: 6, diamond_hole: 7) cannot support a benchmark and must be
    either dropped or regenerated -- that decision is reported, not hidden.
 3. Re-runs the three-protocol comparison (random-within / random-pooled / family-disjoint)
    on the deduplicated set at matched training size, so the gap can be compared directly
    against the duplicated-set numbers.

The output is the honest version of the headline table.
"""
import json, os, sys, time
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import RidgeCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import r2_score

sys.path.insert(0, "/mnt/user-data/outputs/p3/code")
os.environ.setdefault("SELPREFIX", "clean48_")
from run_feature2 import FAMS

DATA = "/mnt/user-data/outputs/9_PROJECT_STATE/data"
OUT = "/mnt/user-data/outputs/p4/results/dedup.json"
COL = {"C11": 0, "C12": 1, "C22": 3, "C33": 5}      # raw y column indices (KEEP = [0,1,3,5])
MIN_CELLS = 40                                       # a family needs this many distinct cells

def load(f):
    X = np.load(f"{DATA}/clean48_{f}__X.npy")
    y = np.load(f"{DATA}/clean48_{f}__y.npy")
    return X.reshape(len(X), -1), y

def dedup(X, y):
    _, keep = np.unique(X, axis=0, return_index=True)
    keep = np.sort(keep)
    return X[keep], y[keep]

def main():
    print("=" * 78)
    print("DEDUPLICATED BENCHMARK")
    print("=" * 78)
    D, dropped = {}, []
    print(f"{'family':16s}{'raw':>6s}{'distinct':>10s}   status")
    for f in FAMS:
        X, y = load(f)
        Xd, yd = dedup(X, y)
        if len(Xd) < MIN_CELLS:
            dropped.append((f, len(Xd)))
            print(f"{f:16s}{len(X):6d}{len(Xd):10d}   DROPPED (< {MIN_CELLS} distinct)")
        else:
            D[f] = (Xd, yd)
            print(f"{f:16s}{len(X):6d}{len(Xd):10d}   kept")
    fams = list(D)
    cap = min(len(D[f][0]) for f in fams)
    print(f"\n  {len(fams)} of {len(FAMS)} families usable; "
          f"{len(dropped)} dropped: {[d[0] for d in dropped]}")
    print(f"  per-family cap set by the smallest surviving family: {cap} cells")
    print(f"  total usable cells: {len(fams) * cap}")

    rng = np.random.default_rng(0)
    for f in fams:
        X, y = D[f]
        i = rng.permutation(len(X))[:cap]
        D[f] = (X[i].astype(np.float32), y[i])

    LEARNERS = {
        "ridge": lambda: make_pipeline(StandardScaler(with_mean=False),
                                       RidgeCV(alphas=np.logspace(-2, 4, 13))),
        "RF":    lambda: RandomForestRegressor(n_estimators=60, random_state=0,
                                               max_features=0.3, min_samples_leaf=2, n_jobs=1),
    }

    def stack(fs, col, idx=None):
        xs, ys = [], []
        for f in fs:
            i = slice(None) if idx is None else idx[f]
            xs.append(D[f][0][i]); ys.append(D[f][1][i][:, col])
        return np.vstack(xs), np.concatenate(ys)

    K = 4
    subs = []
    r2 = np.random.default_rng(7)
    while len(subs) < 20:
        c = tuple(sorted(r2.choice(fams, K, replace=False)))
        if c not in subs:
            subs.append(c)

    R = json.load(open(OUT)) if os.path.exists(OUT) else {}
    R["_meta"] = dict(families=fams, dropped=dropped, cap=int(cap))
    print("\n" + "=" * 78)
    print("HONEST SPLIT GAP, deduplicated (median over 20 subsets)")
    print("=" * 78)
    print(f"{'target':8s}{'learner':8s}{'within':>10s}{'pooled':>10s}{'disjoint':>11s}{'gap':>9s}")
    for tname, col in COL.items():
        for ln, mk in LEARNERS.items():
            key = f"{tname}|{ln}"
            if key in R:
                s = R[key]
            else:
                w, p, d = [], [], []
                for sub in subs:
                    tr_f = list(sub); te_f = [f for f in fams if f not in sub]
                    n_train = K * cap
                    # disjoint
                    Xtr, ytr = stack(tr_f, col); Xte, yte = stack(te_f, col)
                    d.append(r2_score(yte, mk().fit(Xtr, ytr).predict(Xte)))
                    # random-pooled, matched training size
                    per = int(np.ceil(n_train / len(fams)))
                    itr, ite = {}, {}
                    for f in fams:
                        pm = rng.permutation(cap); itr[f] = pm[:per]; ite[f] = pm[per:]
                    Xp, yp = stack(fams, col, itr)
                    k = rng.permutation(len(yp))[:n_train]
                    Xp_te, yp_te = stack(fams, col, ite)
                    p.append(r2_score(yp_te, mk().fit(Xp[k], yp[k]).predict(Xp_te)))
                    # random-within
                    iw, iwt = {}, {}
                    for f in tr_f:
                        pm = rng.permutation(cap); c0 = int(.75 * cap)
                        iw[f] = pm[:c0]; iwt[f] = pm[c0:]
                    Xw, yw = stack(tr_f, col, iw); Xw_te, yw_te = stack(tr_f, col, iwt)
                    w.append(r2_score(yw_te, mk().fit(Xw, yw).predict(Xw_te)))
                s = dict(within=float(np.median(w)), pooled=float(np.median(p)),
                         disjoint=float(np.median(d)))
                R[key] = s
                json.dump(R, open(OUT + ".tmp", "w")); os.replace(OUT + ".tmp", OUT)
            print(f"{tname:8s}{ln:8s}{s['within']:+10.3f}{s['pooled']:+10.3f}"
                  f"{s['disjoint']:+11.3f}{s['within']-s['disjoint']:+9.3f}", flush=True)
    json.dump(R, open(OUT, "w"))
    print("\nCompare against the DUPLICATED-set numbers in splitgap.json to see how much of")
    print("the original gap was memorisation of repeated cells.")
    print("DONE")

if __name__ == "__main__":
    main()
