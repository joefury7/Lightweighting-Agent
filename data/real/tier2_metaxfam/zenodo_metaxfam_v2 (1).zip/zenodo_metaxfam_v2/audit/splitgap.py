"""
splitgap.py -- the spine of the benchmark paper.

CLAIM UNDER TEST.  Surrogates for homogenized stiffness are almost always evaluated with
RANDOM splits over a pooled cell dataset.  If the dataset contains several unit-cell
topology families, a random split puts cells from every family in both train and test, so
the reported score measures interpolation within known families.  A FAMILY-DISJOINT split
-- holding out whole topology families -- measures what a practitioner actually needs: does
the surrogate work on a topology it has never seen?

THE CONTROL THAT MAKES THIS AN EXPERIMENT RATHER THAN A COMPARISON.  A family-disjoint
split with K training families gives K x N_per training cells.  If we compared that to a
random split over all 22 families, the two arms would differ in BOTH split protocol and
training-set diversity, and the gap could be dismissed as a sample-size or coverage effect.
So the random arm is drawn to have EXACTLY the same number of training cells, and we
additionally report a random arm restricted to the same K families ("random-within"), which
isolates protocol from coverage:

    disjoint      : train on K whole families, test on the other 22-K   <- honest protocol
    random-pooled : same #cells, drawn at random from all 22 families   <- standard practice
    random-within : same #cells, drawn at random from the SAME K families, test on held-out
                    cells of those same families                        <- pure interpolation

If the gap is real, random-pooled and random-within both look excellent and disjoint
collapses -- and the difference between random-within and disjoint is the honest measure of
what the standard protocol hides.

Four targets (C11, C12, C22, C66), three surrogate classes, 20 subsets, 2 seeds.
"""
import json, os, sys, time
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.linear_model import RidgeCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import r2_score

sys.path.insert(0, "/mnt/user-data/outputs/p3/code")
os.environ.setdefault("SELPREFIX", "clean48_")
import ablate2 as A, robust as RB
from run_feature2 import FAMS

OUT = "/mnt/user-data/outputs/p4/results/splitgap.json"
os.makedirs(os.path.dirname(OUT), exist_ok=True)

sel = A.selection()
C = A.load("/mnt/user-data/outputs/descriptors_v2_24grey", sel)
# targets: y columns are [C11, C12, C22, C66] in the loader's KEEP order
TARGETS = {"C11": 0, "C12": 1, "C22": 2, "C33": 3}
X = {f: C[f]["X"] for f in FAMS}                      # raw 48x48 pixels, standard input
NPER = len(next(iter(X.values())))

LEARNERS = {
    "ridge": lambda: make_pipeline(StandardScaler(with_mean=False),
                                   RidgeCV(alphas=np.logspace(-2, 4, 13))),
    "RF":    lambda: RandomForestRegressor(n_estimators=60, random_state=0,
                                           max_features=0.3, min_samples_leaf=2, n_jobs=1),
    "MLP":   lambda: make_pipeline(StandardScaler(with_mean=False),
                                   MLPRegressor(hidden_layer_sizes=(128, 64), max_iter=600,
                                                random_state=0, early_stopping=True)),
}

def stack(fams, col, idx=None):
    xs, ys = [], []
    for f in fams:
        i = slice(None) if idx is None else idx[f]
        xs.append(X[f][i]); ys.append(C[f]["y"][i][:, col])
    return np.vstack(xs).astype(np.float32), np.concatenate(ys)

def run_subset(train_fams, col, seed):
    """Three protocols, identical training-set size, identical model."""
    rng = np.random.default_rng(seed + 991)
    test_fams = [f for f in FAMS if f not in train_fams]
    n_train = len(train_fams) * NPER
    out = {}

    # --- 1. family-disjoint: whole families held out
    Xtr, ytr = stack(train_fams, col)
    Xte, yte = stack(test_fams, col)

    # --- 2. random-pooled: same #cells drawn at random from ALL families
    per = int(np.ceil(n_train / len(FAMS)))
    idx_tr, idx_te = {}, {}
    for f in FAMS:
        p = rng.permutation(NPER)
        idx_tr[f] = p[:per]; idx_te[f] = p[per:]
    Xrp, yrp = stack(FAMS, col, idx_tr)
    keep = rng.permutation(len(yrp))[:n_train]
    Xrp, yrp = Xrp[keep], yrp[keep]
    Xrp_te, yrp_te = stack(FAMS, col, idx_te)

    # --- 3. random-within: same #cells, but only the K training families
    idx_w_tr, idx_w_te = {}, {}
    frac = 0.75
    for f in train_fams:
        p = rng.permutation(NPER); c = int(frac * NPER)
        idx_w_tr[f] = p[:c]; idx_w_te[f] = p[c:]
    Xw, yw = stack(train_fams, col, idx_w_tr)
    Xw_te, yw_te = stack(train_fams, col, idx_w_te)

    for ln, mk in LEARNERS.items():
        m = mk().fit(Xtr, ytr)
        out[f"{ln}|disjoint"] = float(r2_score(yte, m.predict(Xte)))
        m = mk().fit(Xrp, yrp)
        out[f"{ln}|random_pooled"] = float(r2_score(yrp_te, m.predict(Xrp_te)))
        m = mk().fit(Xw, yw)
        out[f"{ln}|random_within"] = float(r2_score(yw_te, m.predict(Xw_te)))
    return out

def main():
    subs = RB.subsets()[:20]
    R = json.load(open(OUT)) if os.path.exists(OUT) else {}
    for tname, col in TARGETS.items():
        for seed in (0, 1):
            key = f"{tname}|seed{seed}"
            if key in R:
                continue
            t0 = time.time()
            recs = [run_subset(list(s), col, seed) for s in subs]
            R[key] = recs
            agg = {k: float(np.median([r[k] for r in recs])) for k in recs[0]}
            print(f"  {tname} seed{seed}  ({time.time()-t0:.0f}s)", flush=True)
            for ln in LEARNERS:
                print(f"      {ln:6s} within {agg[f'{ln}|random_within']:+.3f}   "
                      f"pooled {agg[f'{ln}|random_pooled']:+.3f}   "
                      f"DISJOINT {agg[f'{ln}|disjoint']:+.3f}", flush=True)
            json.dump(R, open(OUT + ".tmp", "w")); os.replace(OUT + ".tmp", OUT)

    print("\n" + "=" * 78)
    print("THE GAP: what the standard protocol hides (median over 20 subsets x 2 seeds)")
    print("=" * 78)
    print(f"{'target':8s}{'learner':8s}{'random-within':>15s}{'random-pooled':>15s}"
          f"{'family-disjoint':>17s}{'gap':>9s}")
    summary = {}
    for tname in TARGETS:
        for ln in LEARNERS:
            recs = R[f"{tname}|seed0"] + R[f"{tname}|seed1"]
            w = np.median([r[f"{ln}|random_within"] for r in recs])
            p = np.median([r[f"{ln}|random_pooled"] for r in recs])
            d = np.median([r[f"{ln}|disjoint"] for r in recs])
            summary[f"{tname}|{ln}"] = dict(within=w, pooled=p, disjoint=d, gap=w - d)
            print(f"{tname:8s}{ln:8s}{w:+15.3f}{p:+15.3f}{d:+17.3f}{w-d:+9.3f}")
    R["_summary"] = summary
    json.dump(R, open(OUT, "w"))
    print("\nDONE")

if __name__ == "__main__":
    main()
