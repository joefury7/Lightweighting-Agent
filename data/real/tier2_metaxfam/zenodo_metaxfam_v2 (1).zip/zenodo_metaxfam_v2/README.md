# MetaXFam-D — a distinct-rasterisation benchmark for cross-topology generalization of homogenization surrogates

**Version 2.0.0.** This version corrects a significant defect in version 1 (MetaXFam22).
Read the next section before using either version.

---

## What was wrong with version 1, and by how much

Version 1 of this record contained 13,200 unit cells across 22 parametric families,
600 per family. An audit found that **only 5,072 of those 13,200 cells are distinct
geometries — a duplicate rate of 61.6%**.

The cause is *rasterisation collapse*. The generators sample continuous shape parameters,
but on a 48×48 grid many distinct parameter values produce the identical pixel image. A
family with few shape parameters exhausts the set of achievable rasterisations quickly and
then emits copies indefinitely. Per-family, the effect ranged from negligible to total:

| family | cells in v1 | distinct geometries |
|---|---|---|
| `diag_lattice` | 600 | **3** |
| `square`, `square_lattice` | 600 | **6** |
| `diamond_hole` | 600 | 7 |
| `layered` | 600 | 21 |
| `rect_hole` | 600 | 30 |
| `cross` | 600 | 47 |
| `circle` | 600 | 65 |
| `kagome` | 600 | 69 |
| `rect_lattice` | 600 | 80 |
| `hex_hole` | 600 | 172 |
| `ellipse`, `rand_lattice` | 600 | 600 (clean) |

The mechanism is confirmed by the resolution dependence, measured on an 8-family probe:
duplication is 72.8% at 48×48, 92.3% at 24×24, 96.7% at 16×16 and 98.4% at 12×12. Coarser
rasterisation means fewer achievable images means more collisions.

**The practical consequence: under a random 75/25 split of v1, 67.7% of test cells have
their exact geometry present in the training set.** Any in-distribution or random-split
score computed on version 1 is therefore inflated by memorisation of repeated cells and
should not be relied on.

Cross-*family* results computed on v1 are much less affected — whole families are held out,
and only 40 duplicate groups span more than one family — but they were computed on a pool
whose effective size was far smaller than stated.

**Version 1 has not been withdrawn.** It remains available and citable because published
work refers to it. Use version 2 for new work.

### Is this a problem with pixelised metamaterial datasets generally?

Not on the evidence available here. The published 2D unit-cell subsets of METASET
(Chan, Ahmed, Wang & Chen, *J. Mech. Des.* 143(3), 2021) were audited with the same script
and show **0% duplication within every subset** at 50×50. METASET selects for diversity
explicitly and uses higher-dimensional shape descriptions. The defect documented here is a
property of *these* low-parameter generators, not of pixelised datasets as a class. A
larger public dataset (Wang et al. 2020, 90,245 cells) was not audited because it was not
reachable from the audit environment; anyone with it can run `audit/dup_audit.py`.

---

## What version 2 contains

### `data_benchmark/` — the recommended benchmark (MetaXFam-D)
**18 families × 172 cells = 3,096 cells, verified 3,096 distinct (zero duplicates).**
Every family contributes equally so no family dominates pooled evaluation. Solid-fraction
family medians span 0.579–0.695, preserving the density de-confounding that motivated the
original dataset.

Six families were re-parameterised to escape exhaustion (`*_rich`): the original one- and
two-parameter forms could not span enough rasterisations. Each keeps the property that
defines it while gaining shape freedom — for example `circle_rich` is an elliptical hole
with free area, aspect and orientation (3 degrees of freedom, versus radius alone).
**Note that `circle_rich` is therefore no longer exactly isotropic**; the exactly-isotropic
circular family is preserved separately as `circle_iso`, which has only 65 distinct members
— that is the true number available at this resolution, not a sampling shortfall.

### `data_full_pool/` — everything generated
All 29 families (22 original + 7 re-parameterised) at their full achievable distinct count,
7,190 cells total. Use this if you want families below the benchmark's 150-cell threshold,
or to study the exhaustion phenomenon itself.

### `code/` — generators
`gen_distinct.py` regenerates any family with the distinct-rasterisation filter and reports
whether the family reached the target, EXHAUSTED (its parameterisation is enumerated), or
TIMEBOX. `families_rich.py` holds the re-parameterised families. `homogenize2d.py` is the
periodic FE solver, validated by `test_homogenize.py`.

### `audit/` — the tooling and results
`dup_audit.py` reproduces every number in the section above. Run it on your own dataset:
the core check is three lines.

```python
import numpy as np
X = cells.reshape(len(cells), -1)          # (N, H*W) binary
print(len(X), "cells ->", len(np.unique(X, axis=0)), "distinct")
```

---

## File format

`clean48_<family>__X.npy` — `uint8`, shape `(N, 48, 48)`, 1 = solid, 0 = void.
`clean48_<family>__y.npy` — `float64`, shape `(N, 6)`, the homogenised stiffness in Voigt
order `[C11, C12, C13, C22, C23, C33]` (plane strain, E_solid = 1, ν = 0.3, void E = 1e-6).
`clean48_<family>__frac.npy` — `float64`, shape `(N,)`, solid volume fraction.

Every cell satisfies: solid fraction in [0.45, 0.75]; the solid phase percolates in both
directions under periodic boundary conditions; and its 48×48 rasterisation is unique within
its family.

## Reproducing

```bash
cd code && python test_homogenize.py          # 6 solver validation tests
python gen_distinct.py 400                    # regenerate all families, filtered
cd ../audit && python dup_audit.py            # reproduce the v1 duplication audit
python benchmark_v2.py                        # assemble MetaXFam-D and run the split-gap
```

Requires only NumPy, SciPy and scikit-learn. Runs on one CPU core.

## Citing

Cite this record by version. If your work used version 1, cite version 1 and note the
duplication issue where in-distribution scores are involved.

## Licence

Code MIT; data and results CC BY 4.0.

## Contact

David Mashiah — davidmashiah@mail.tau.ac.il — ORCID 0009-0004-4684-955X
